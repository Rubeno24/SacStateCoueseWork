package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

//Extends Fixed since FoodStation doesn't move
public class FoodStation extends Fixed{
	//Class Fields
	private int capacity;

	public FoodStation(int size, float x, float y) {
		//Calling the constructor from the GameOject Class
		super(size,x,y);
		//uses the setColor method from the GameObject class to set the color to green
		super.setColor(ColorUtil.rgb(0, 255, 0));
		//The initial capacity is proportional to the size of the food station
		capacity=size;
	}
	
	//returns the capacity of the food station
	public int getCapacity() {
		return capacity;
	}
	//sets the capacity to zero when ant eats from the FoodStation
	public void setCapacitytoZero() {
		capacity=0;
	}
	//toString method for FoodSation uses the GameObjects to String and then adds
	//its own attributes
	public String toString() {
		return "FoodStation: "+super.toString()+" capacity: "+capacity;
	}

}