package com.mycompany.a2;
//interface that food consumers implement
public interface IFoodie {
	 public void setFoodConsumption();
	
}
