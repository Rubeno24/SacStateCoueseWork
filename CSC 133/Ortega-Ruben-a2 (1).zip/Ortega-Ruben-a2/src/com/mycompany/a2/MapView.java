package com.mycompany.a2;
import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer{
	private  GameWorld gw;
	//command Constructor
	public MapView(GameWorld gw) {
		this.gw= gw;
		this.gw.addObserver(this);

	}

	@Override
	public void update(Observable observable, Object data) {
		//calls the map method that was previously the 'm' key
		gw.map();
		
	}

}
