package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Label;
import java.lang.String;

public class Game extends Form {
	private GameWorld gw;
	private MapView mv; // new in A2
	private ScoreView sv; // new in A2

	// GameWorld instance in instantiated in the Game Constructor
	public Game() {
		gw = new GameWorld(); // create Observable GameWorld
		mv = new MapView(gw); // create an Observer for the map
		sv = new ScoreView(gw); // create an Observer for the game/ant state data
		gw.addObserver(mv); // register the map observer
		gw.addObserver(sv);// register the score observer

		// set the layout to BorderLayout be divided into five areas: one for score
		// information, three for commands, and
		// one for the map (which will be an empty container) for now
		this.setLayout(new BorderLayout());

		// Command Objects
		Command accelerateCommand = new AccelerateCommand(gw);
		Command brakeCommand = new BrakeCommand(gw);
		Command leftCommand = new LeftCommand(gw);
		Command rightCommand = new RightCommand(gw);
		Command foodConsumptionCommand = new FoodConsumptionCommand(gw);
		Command flagCollisionCommand = new FlagCommand(gw);
		Command foodStationCollisionCommand = new FoodStationCollisionCommand(gw);
		Command spiderCollisionCommand = new SpiderCollisionCommand(gw);
		Command tickCommand = new TickCommand(gw);
		Command exitCommand = new ExitCommand(gw);
		Command soundCommand = new SoundCommand(gw);
		Command aboutCommand = new AboutCommandd(gw);
		Command helpCommand = new HelpCommand(gw);

		// key bindings
		addKeyListener('a', accelerateCommand);
		addKeyListener('b', brakeCommand);
		addKeyListener('t', tickCommand);
		addKeyListener('l', leftCommand);
		addKeyListener('r', rightCommand);
		addKeyListener('g', spiderCollisionCommand);
		addKeyListener('f', foodStationCollisionCommand);
		addKeyListener('c', foodConsumptionCommand);

		// buttons used for the on screen commands
		MyButton tickButton = new MyButton();
		MyButton accelerateButton = new MyButton();
		MyButton brakeButton = new MyButton();
		MyButton flagCollision = new MyButton();
		MyButton leftButton = new MyButton();
		MyButton rightButton = new MyButton();
		MyButton spiderCollisionButton = new MyButton();
		MyButton foodStationCollisionButton = new MyButton();

		// on screen commands
		tickButton.setCommand(tickCommand);
		accelerateButton.setCommand(accelerateCommand);
		brakeButton.setCommand(brakeCommand);
		flagCollision.setCommand(flagCollisionCommand);
		leftButton.setCommand(leftCommand);
		rightButton.setCommand(rightCommand);
		spiderCollisionButton.setCommand(spiderCollisionCommand);
		foodStationCollisionButton.setCommand(foodStationCollisionCommand);

		// side menu items
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		toolbar.addCommandToSideMenu(accelerateCommand);
		toolbar.setTitle("The Journey Game ");
		CheckBox soundCheck = new CheckBox("Sound");
		soundCheck.getStyle().setFgColor(ColorUtil.WHITE);
		soundCheck.setCommand(soundCommand);
		toolbar.addComponentToSideMenu(soundCheck);
		toolbar.addCommandToSideMenu(aboutCommand);
		toolbar.addCommandToSideMenu(exitCommand);
		toolbar.addCommandToRightBar(helpCommand);

		// west container
		Container westContainer = new Container();
		westContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLACK));
		westContainer.setLayout(new BoxLayout(2));
		westContainer.add(accelerateButton);
		this.add(BorderLayout.WEST, westContainer);
		westContainer.add(leftButton);


		// center container
		Container centerContainer = new Container();
		centerContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.rgb(255, 0, 0)));
		centerContainer.add(mv);
		this.add(BorderLayout.CENTER, centerContainer);

		// South Container
		Container southContainer = new Container();
		southContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLACK));
		southContainer.setLayout(new FlowLayout(Component.CENTER));
		this.add(BorderLayout.SOUTH, southContainer);
		southContainer.add(flagCollision);
		southContainer.add(spiderCollisionButton);
		southContainer.add(foodStationCollisionButton);
		southContainer.add(tickButton);

		// East Container
		Container eastContainer = new Container();
		eastContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLACK));
		eastContainer.setLayout(new BoxLayout(2));
		eastContainer.add(brakeButton);
		this.add(BorderLayout.EAST, eastContainer);
		eastContainer.add(rightButton);

		// North Container
		Container North = new Container();
		sv.getAllStyles().setBorder(Border.createLineBorder(0, ColorUtil.WHITE));
		sv.getAllStyles().setMarginLeft(300);
		North.add(sv);
		this.add(BorderLayout.NORTH, North);
		
		gw.setMapHeight(mv.getComponentForm().getHeight());//created a method
		gw.setMapWidth(mv.getComponentForm().getWidth());//created a method
		
	
		this.show();
		gw.setMapHeight(mv.getComponentForm().getHeight());//created a method
		gw.setMapWidth(mv.getComponentForm().getWidth());//created a method
		gw.init();
		//without show method being called nothing will be displayed

	}
	//play method commented out because no longer used.
	// play method provided for us. We had to correctly implement a command for each
	// switch case when ever the user presses the corresponding key
	/*
	 * @SuppressWarnings("unused") private void play() { Label myLabel = new
	 * Label("Enter a Command:"); this.addComponent(myLabel); final TextField
	 * myTextField = new TextField(); this.addComponent(myTextField); this.show();
	 * myTextField.addActionListener(new ActionListener() { public void
	 * actionPerformed(ActionEvent evt) { String sCommand =
	 * myTextField.getText().toString(); myTextField.clear(); if (sCommand.length()
	 * != 0) { switch (sCommand.charAt(0)) { case 'a': gw.setAntSpeed(5); break;
	 * case 'b': gw.setAntSpeed(-5); break; case 'l': gw.changeHeading('l'); break;
	 * case 'r': gw.changeHeading('r'); break; case 'c':
	 * gw.setAntFoodConsuptionRate(); break; case '1': //flag 1
	 * gw.simulateFlagCollision(1); break; case '2': //flag 2
	 * gw.simulateFlagCollision(2); break; case '3': //flag 3
	 * gw.simulateFlagCollision(3); break; case '4': //flag 4
	 * gw.simulateFlagCollision(4); break; case '5': //flag 5
	 * gw.simulateFlagCollision(5); break; case '6': //flag 6
	 * gw.simulateFlagCollision(6); break; case '7': //flag 7
	 * gw.simulateFlagCollision(7); break; case '8': //flag 8
	 * gw.simulateFlagCollision(8); break; case '9': //flag 9
	 * gw.simulateFlagCollision(9); break; case 'f':
	 * gw.simulatefoodStationCollision(); break; case 'g': gw.spiderCollision();
	 * break; case 't': gw.tick(); break; case 'd': gw.display(); break; case 'm':
	 * gw.map(); break; case 'x':
	 * myLabel.setText("Do you want to exit? Press y or n!"); gw.quitGame(); break;
	 * case 'y': gw.exit(); break; case 'n': myLabel.setText("Enter a command!");
	 * gw.dontQuit(); break;
	 * 
	 * 
	 * } } // add code to handle rest of the commands // switch } // actionPerformed
	 * } // new ActionListener() ); // addActionListener } // play}
	 */
}
