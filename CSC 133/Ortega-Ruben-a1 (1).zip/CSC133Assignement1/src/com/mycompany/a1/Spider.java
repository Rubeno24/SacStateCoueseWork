package com.mycompany.a1;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
//Extends Movable since Ant moves
public class Spider extends Moveable{
	private Random random = new Random(); 
	private float XLocation;
	private float YLocation;

	
	public Spider(int size, float x, float y) {
		super(size,x,y);
		//sets spider color to black
		super.setColor(ColorUtil.rgb(0, 0, 0));
		//picks a random speed between 5 and 10
		super.setSpeed(randomSpeed());
		super.setHeading(randomInitalHeading());
	}
	@Override
	public void setColor(int color) {
		//no code since they cannot change colors
	}
	
	//returns a random speed between 5 and 10
	public int randomSpeed() {
		return 5 + random.nextInt(10);
	}
	
	//returns a random heading between 0 and 360
	public int randomInitalHeading() {
		return  random.nextInt(359);
	}

	//returns a random number between -7 amd 7
	public int getRandomHeading() {
		 return random.nextInt(7) * (random .nextBoolean() ? -1 : 1);
	}
	//toString method from the constructor class with added attributes of the spider.
	public String toString() {
		return "Spider: "+super.toString()+" heading="+super.getHeading()+" speed="+getSpeed();
	}
	
	//this method generates the x and y values for the spider then it checks to see if the spider is out of bounds
	//for now our bounds is 1000x1000. so if its out of bounds we change the heading by 180 turning the spider around
	public  void moveSpider() {
		XLocation =  (float) (getXLocation()+(Math.cos(Math.toRadians(90-getHeading())))*getSpeed());
		YLocation = (float) (getYLocation()+(Math.sin(Math.toRadians(90-getHeading())))*getSpeed());
		 if(YLocation>=990.0) {
				super.setHeading(super.getHeading()-180);
				YLocation = (float) (getYLocation()+(Math.sin(Math.toRadians(90-getHeading())))*getSpeed());
				super.move(XLocation,YLocation);
			}
		 
		 if(YLocation<=8.0) {
				super.setHeading(super.getHeading()-180);
				YLocation = (float) (getYLocation()+(Math.sin(Math.toRadians(90-getHeading())))*getSpeed());
				super.move(XLocation,YLocation);
			}
		 
		 if(XLocation>=990.0) {
				super.setHeading(super.getHeading()-180);
				XLocation = (float) (getYLocation()+(Math.sin(Math.toRadians(90-getHeading())))*getSpeed());
				super.move(XLocation,YLocation);
			}
		 
		 if(XLocation<=8.0) {
				super.setHeading(super.getHeading()-180);
				XLocation = (float) (getYLocation()+(Math.sin(Math.toRadians(90-getHeading())))*getSpeed());
				super.move(XLocation,YLocation);
			}
		 else {
		
		super.move(XLocation,YLocation);
			}
		 }
}
