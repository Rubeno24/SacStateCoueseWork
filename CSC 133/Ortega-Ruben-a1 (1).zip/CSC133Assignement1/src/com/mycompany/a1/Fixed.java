package com.mycompany.a1;
//A type of GameObject that does not move
public abstract class Fixed extends GameObject{
	
	//Fixed Constructor
	public Fixed(int size, float x, float y) {
		//Calling the constructor from the GameOject Class
		super(size,x,y);
	
	}
	
	//Method that sets a new x_Location 
	@Override
	public void setXLocation(float x) {
		//doesn't change location since they are fixed
	}
	//Method that sets a new y_Location 
	@Override
	public void setYLocation(float y) {
		//doesn't change location since they are fixed
	}

}
