package com.mycompany.a1;

import java.util.ArrayList;
import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class GameWorld {
	//class fields
	//ArrayList a collection of type GameObjects holds 4 Flags, 1 Ant, 1 Spider and 2 FoodStations
	private ArrayList<GameObject> GameObjects = new ArrayList<GameObject>();
	private boolean Exit = false;
	private Ant ant ;
	private Random rand = new Random();
	private int clock=0;
	private int lives=3;
	private int flagSize = 20;
	
	/*
	 disclaimer if my ants health is at 0 or the lives is at 0 is wont lose a life until 
	 the t command is pressed. Same if it has 0 lives it wont display the game over 
	 until the game has ticked again.also I left in print statements that are meant to 
	 help the user visualize what has changed. For example if the speed is increased
	 it will print the increased speed to the console. All the data is still updated in the 
	 'm' and 'd' commands. If this bothers you please let me know and I can remove it.
	 */
	
	//init method where all game objects are created
	public void init() {
		
		//Flag(size,x_location,y_location,sequence_number)
		GameObjects.add(new Flag(flagSize, 100, 100, 1));
		GameObjects.add(new Flag(flagSize, 200, 200, 2));
		GameObjects.add(new Flag(flagSize, 300, 300, 3));
		GameObjects.add(new Flag(flagSize, 400, 400, 4));
		
		//Ant(size,x_location,y_location,heading)
		GameObjects.add(ant = new Ant(30, 100, 100, 0));
		
		//Spider(size,x_location,y_location)
		GameObjects.add(new Spider(getRandomSize(), getRandomXLocation(), getRandomYLocation()));
		
		//FoodStation(size,x_location,y_location)
		GameObjects.add(new FoodStation(getRandomSize(), getRandomXLocation(), getRandomYLocation()));
		GameObjects.add(new FoodStation(getRandomSize(), getRandomXLocation(), getRandomYLocation()));
	}

	//this method is used for command 'a' and command 'b' it adjusts the speed of the ant
	//by adding positive or negative values to the speed
	public void setAntSpeed(int i) {
		ant.adjustSpeed(i);
		System.out.println("Ant speed set to: "+ant.getSpeed());
		
	}
	//this method is used for command 'L' and command 'r' it adjusts the heading of the ant
	//by adding positive or negative values to the heading
	public void changeHeading(char x) {
		ant.changeAntHeading(x);
		System.out.println("Ant Heading: "+ ant.getHeading());
	}
	//this method sets the food consumption rate of the ant to its default value of 5 and is command 'c'
	public void setAntFoodConsuptionRate() {
		ant.setFoodConsumption();	
		System.out.println("Food consumption set to: "+ant.getFoodConsumption());
	}
	//this method is used for command '1-9'
	public void simulateFlagCollision (int flagNumber) {
		ant.checkFlagCollision(flagNumber);
		System.out.println("Flag number: "+ant.getLastFlagReached());
	}
	
	//this method is used for comman 'f' it loops through the arraylist of type GameObjects 
	//and looks for foodstation that are not empty. It gets their capacity which depends on the 
	//size and adds them to the foodlevel of the ant. Then it sets the capacity to 0 and
	//sets their color to a light green meaning that they are used. Then it creates a new foodstation
	//since one was used up. The used food station stays on the map.
	public void simulatefoodStationCollision() {
		for(int i=0; i<GameObjects.size();i++) {
			if(GameObjects.get(i) instanceof FoodStation) {
				if(((FoodStation)GameObjects.get(i)).getCapacity()!=0){
					ant.addTofoodLevel(((FoodStation)GameObjects.get(i)).getCapacity());
					((FoodStation)GameObjects.get(i)).setCapacitytoZero();
					//sets color to light green
					GameObjects.get(i).setColor(ColorUtil.rgb(144, 238, 144));
					break;
				}
				
			}
			
		}
		
		GameObjects.add(new FoodStation(getRandomSize(), getRandomXLocation(), getRandomYLocation()));
		System.out.println("Food Station Consumed");
		System.out.println("Ant food level: "+ant.getFoodLevel());
		System.out.println("Ant speed level: "+ant.getSpeed());
	}
	//this method is for command 'g' and calls a method in the ant class that simulates a collision with an ant 
	public void spiderCollision() {
		ant.simulateSpiderCollison();

	}
	/*this method is for the command 't' it means that the clock has ticked. Which means spiders update their
	 * heading(1), all moveable objects update their positions according to their and speed(2) in this case its only
	 * spider and the ant, the ants foodLevel is reduced(3), the gameclock is incremented by 1(4),
	 * */
	public void tick() {
		logic();
		incrementgameClock();//(4)
		ant.conusumeFood();//(3)
				for(int i=0; i<GameObjects.size();i++) {
					if(GameObjects.get(i) instanceof 	Moveable) {
						if(GameObjects.get(i) instanceof 	Spider) {
							((Spider)GameObjects.get(i)).setHeading(((Spider)GameObjects.get(i)).getRandomHeading());//(1)
							 ((Spider)GameObjects.get(i)).moveSpider();
						}
						else ((Ant)GameObjects.get(i)).moveAnt(); //(2)
						}
					}
		}

	//login helper method is called when the game ticks and checks to see if the spider
	//needs to have a life removed
	public void logic() {
		if( ant.getHealthLevel()==0) {
			lives=lives-1;
			ant.reset();
			resetClock();
			init();
		}
		if( ant.getFoodLevel()<=0) {
			lives=lives-1;
			ant.reset();
			resetClock();
			init();
		}
		if(lives<=0) {
			System.out.println("Game over, you failed!");
			
		}
		if(ant.getLastFlagReached()==9) {
			System.out.println("Game over, you win!   Total time: "+clock);
		}
	
	}
	//this method is for the 'd' command and it displays the lives, flag, food and health 
	//level of the ant and the clock.
	public void display() {
		System.out.println("Remaining Ant Lives: "+lives);
		System.out.println("Clock value: "+clock);
		System.out.println("Higest Flag Reached: "+ant.getLastFlagReached());
		System.out.println("Ant Food Level: "+ ant.getFoodLevel());
		System.out.println("Ant Health level: "+ant.getHealthLevel());

	}
	// this method is used for the 'm' command and prints the x and y location
	//of the game objects and the color,size and other object specific information
	public void map() {
		for (int i=0;i<GameObjects.size();i++) {
			System.out.println(GameObjects.get(i).toString());
		}
	}
	//this method is used for the 'x' command it quies the game if the boolean exit is true
	public void exit() {
		if (Exit)
			System.exit(0);
	}
	//asks the user to enter 'y or Y' exit boolean is true and game is quit
	public void quitGame() {
		System.out.println("Do you want to exit? Press y or n!");
		Exit=true;
	}
	//if user enters 'n or N' the game continues
	public void dontQuit() {
		Exit=false;
		System.out.println("Enter a command");
	}

	//random helper methods
	//returns a random x location between 0 and 1000
	public int getRandomXLocation() {
		return rand.nextInt(1000-0)+0;
	}
	//returns a random y location between 0 and 1000
	public int getRandomYLocation() {
		return rand.nextInt(1000-0)+0;
	}
	//returns a random number between 10 and 20 and used for the size variable of objects
	 int getRandomSize() {
		return rand.nextInt((20-10)+1)+10;
	}
	//clock helper methods
	//increments the clock by 1
	public void incrementgameClock() {
		clock+=1;
	}
	//resets the clock
	public void resetClock() {
		clock=0;
	}


}
