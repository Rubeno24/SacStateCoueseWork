package com.mycompany.a1;

import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import java.lang.String;

public class Game extends Form {
	private GameWorld gw;

	// GameWorld instance in instantiated in the Game Constructor
	public Game() {
		gw = new GameWorld();
		gw.init();
		play();
		 
	}
	
	//play method provided for us. We had to correctly implement a command for each
	//switch case when ever the user presses the corresponding key
	private void play() {
		Label myLabel = new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField = new TextField();
		this.addComponent(myTextField);
		this.show();
		myTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String sCommand = myTextField.getText().toString();
				myTextField.clear();
				if (sCommand.length() != 0) {
					switch (sCommand.charAt(0)) {
						case 'a':
							gw.setAntSpeed(5);
							break;
						case 'b':
							gw.setAntSpeed(-5);
							break;
						case 'l':
							gw.changeHeading('l');
							break;
						case 'r':
							gw.changeHeading('r');
							break;
						case 'c':
							gw.setAntFoodConsuptionRate();
							break;
						 case '1':
					        	//flag 1
					        	gw.simulateFlagCollision(1);
					        	break;
					        case '2':
					        	//flag 2
					        	gw.simulateFlagCollision(2);
					        	break;
					        case '3':
					        	//flag 3
					        	gw.simulateFlagCollision(3);
					        	break;
					        case '4':
					        	//flag 4
					        	gw.simulateFlagCollision(4);
					        	break;
					        case '5':
					        	//flag 5
					        	gw.simulateFlagCollision(5);
					        	break;
					        case '6':
					        	//flag 6
					        	gw.simulateFlagCollision(6);
					        	break;
					        case '7':
					        	//flag 7
					        	gw.simulateFlagCollision(7);
					        	break;
					        case '8':
					        	//flag 8
					        	gw.simulateFlagCollision(8);
					        	break;
					        case '9':
					        	//flag 9
					        	gw.simulateFlagCollision(9);
					        	break;
					        case 'f':
					        	gw.simulatefoodStationCollision();
					        	break;
					        case 'g':
					        	gw.spiderCollision();
					        	break;
					        case 't':
					        	gw.tick();
					        	break;
					        case 'd':
					        	gw.display();
					        	break;
					        case 'm':
					        	gw.map();
					        	break;
					        case 'x':
					        	myLabel.setText("Do you want to exit? Press y or n!");
					        	gw.quitGame();
					        	break;	
					        case 'y':
					        	gw.exit();
					        	break;
					        case 'n':
					        	myLabel.setText("Enter a command!");
					        	gw.dontQuit();
					        	break;
					        	
							
					}
					}
						// add code to handle rest of the commands
					 // switch
			} // actionPerformed
		} // new ActionListener()
		); // addActionListener
	} // play}
}
