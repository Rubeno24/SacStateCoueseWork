package com.mycompany.a1;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;
//parent of every class we created so far
public abstract class GameObject {
	//Class Fields
	private int size;
	private int color;
	//created a new point which will hold x and y float values
	private Point point;


	//GameObject Constructor with size and x and y Locations
	public GameObject(int size, float x_Location, float y_Location) {
		this.size=size;
		point=new Point(x_Location,y_Location);		
	}
	

		
	//Method that sets a new x_Location
	public void setXLocation(float x) {
		point.setX(x);
	}
	
	//Method that sets a new y_Location
	public void setYLocation(float y) {
		point.setY(y);
	}
	
	//returns the x_Location
	public float getXLocation() {
		return point.getX();
	}
	
	//returns the y_Location
	public float getYLocation() {
		return point.getY();
	}
	
	//sets the color 
	public void setColor(int color) {
		this.color=color;
	}
	
	public int getColor() {
		return color;
	}
	
	//returns the size value
	public int getSize() {
		return size;
	}
	
@Override	
public String toString() {
		return  " loc= X:" + Math.round(getXLocation()*10.0)/10.0 + " , Y:" + Math.round(getYLocation()*10.0)/10.0 
				+" color=[" + ColorUtil.red(color)+ "," +ColorUtil.green(color) + "," +ColorUtil.blue(color) + "]" 
				+ " size=" + size;
		
	}

}
