package com.mycompany.a1;
//interface that food consumers implement
public interface IFoodie {
	 public void setFoodConsumption();
	
}
