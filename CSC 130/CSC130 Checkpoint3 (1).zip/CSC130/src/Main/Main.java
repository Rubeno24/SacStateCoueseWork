package Main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import Data.Vector2D;
import Data.spriteInfo;
import logic.Control;
import timer.stopWatchX;

public class Main{
	// Fields (Static) below...
	public static Color c = new Color(79, 52, 235);

	public static stopWatchX timer = new stopWatchX(80);
	
	public static Queue<Vector2D> vecs1 = new LinkedList<>();
	public static Queue<Vector2D> vecs2 = new LinkedList<>();
	public static Vector2D currentVec = new Vector2D(500, 0);
	public static ArrayList<spriteInfo> sprites = new ArrayList<>();
	public static int currentSpriteIndex = 0;
	public static spriteInfo tmp;

	


	
	// End Static fields...
	
	public static void main(String[] args) {
		Control ctrl = new Control();				// Do NOT remove!
		ctrl.gameLoop();							// Do NOT remove!
	}
	
	/* This is your access to things BEFORE the game loop starts */
	public static void start(){
		int counter = 0;
		for (int i = -128; i < 1280 + 128; i += 16) {
			if (counter == 0) {
				sprites.add(new spriteInfo(new Vector2D(i, 250), "ruben1"));
				counter++;
			} else if (counter == 1) {
				sprites.add(new spriteInfo(new Vector2D(i, 250), "ruben2"));
				counter++;
			} else if (counter == 2) {
				sprites.add(new spriteInfo(new Vector2D(i, 250), "ruben3"));
				counter++;
			} else {
				sprites.add(new spriteInfo(new Vector2D(i, 250), "ruben4"));
				counter = 0;
			
		}}
		
		}
		// TODO: Code your starting conditions here...NOT DRAW CALLS HERE! (no addSprite or drawString)
		
	
	
	/* This is your access to the "game loop" (It is a "callback" method from the Control class (do NOT modify that class!))*/
	public static void update(Control ctrl) {
		spriteInfo currSprite = sprites.get(currentSpriteIndex);
		ctrl.addSpriteToFrontBuffer(currSprite.getCoords().getX(), currSprite.getCoords().getY(), currSprite.getTag()); // Add a tester sprite to render list by tag (Remove later! Test only!)

		if (timer.isTimeUp()) {

			if (currentSpriteIndex == (sprites.size() - 1) ) {
				currentSpriteIndex = 0;
			} else {
				currentSpriteIndex++;
			}

			// reset timer obj for next pass
			timer.resetWatch();
		}
	
		
	
	}
}
	
		
		
	
	

			
			
				

				
			
				
			
		

	
	
			

		
		// Add a tester sprite to render list by tag (Remove later! Test only!)
		
		// Test drawing text on screen where you want (Remove later! Test only!)
	
	
	// Additional Static methods below...(if needed)


