package Main;

import java.awt.Color;
import java.util.LinkedList;
import java.util.Queue;

import Data.Vector2D;
import logic.Control;
import timer.stopWatchX;

public class Main{
	// Fields (Static) below...
	public static Color c = new Color(79, 52, 235);

	public static stopWatchX timer = new stopWatchX(8);
	
	public static Queue<Vector2D> vecs1 = new LinkedList<>();
	public static Queue<Vector2D> vecs2 = new LinkedList<>();
	public static Vector2D currentVec = new Vector2D(-100, -100);


	
	// End Static fields...
	
	public static void main(String[] args) {
		Control ctrl = new Control();				// Do NOT remove!
		ctrl.gameLoop();							// Do NOT remove!
	}
	
	/* This is your access to things BEFORE the game loop starts */
	public static void start(){
		for(int i =-128;i<1280;i+=10) {
			Vector2D vec = new Vector2D(i, 250);
			vecs1.add(vec);
		}
		
		// TODO: Code your starting conditions here...NOT DRAW CALLS HERE! (no addSprite or drawString)
		
	}
	
	/* This is your access to the "game loop" (It is a "callback" method from the Control class (do NOT modify that class!))*/
	public static void update(Control ctrl) {
		
		ctrl.addSpriteToFrontBuffer(currentVec.getX(), currentVec.getY(), "ruben");
		ctrl.drawString(70, 250, ""+vecs1.size(), c);
		ctrl.drawString(70, 300, ""+vecs2.size(), c);
		if(timer.isTimeUp()) {
			if(vecs1.isEmpty()==false) {
				currentVec = vecs1.remove();
				vecs2.add(currentVec);
				timer.resetWatch();
			}
			else {
			while  (vecs2.isEmpty()==false){
				
					currentVec = vecs2.remove();
					vecs1.add(currentVec);}
				
				}
			}	
		}
	}
			

		
		// Add a tester sprite to render list by tag (Remove later! Test only!)
		
		// Test drawing text on screen where you want (Remove later! Test only!)
	
	
	// Additional Static methods below...(if needed)


