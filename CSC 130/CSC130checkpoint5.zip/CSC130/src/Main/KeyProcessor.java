/* This will handle the "Hot Key" system. */

package Main;

import logic.Control;
import timer.stopWatchX;

public class KeyProcessor{
	// Static Fields
	private static char last = ' ';			// For debouncing purposes
	private static stopWatchX sw = new stopWatchX(250);
	
	// Static Method(s)
	public static void processKey(char key){
		if(key == ' ')				return;
		// Debounce routine below...
		if(key == last)
			if(sw.isTimeUp() == false)			return;
		last = key;
		sw.resetWatch();
		
		/* TODO: You can modify values below here! */
		switch(key){
		case '%':								// ESC key
			System.exit(0);
			break;
			
		case 'd':
			Main.trigger="d has been triggered";
			//Main.move.adjustX(60);
			//.move.adjustY(0);
			break; 
		case 'a':
			Main.trigger="a has been triggered";
			//Main.move.adjustX(-60);
			//Main.move.adjustY(0);
			break; 
			
		case 'w':
			Main.trigger="w has been triggered";
			//Main.move.adjustX(0);
			//Main.move.adjustY(-60);
			break; 
		case 's':
			Main.trigger="s has been triggered";
			//Main.move.adjustX(0);
			//Main.move.adjustY(60);
			break; 
		case '$':
			Main.trigger="space has been triggered";
			//Main.move.adjustX(0);
			//Main.move.adjustY(60);
			break; 
		
		case 'm':
			// For mouse coordinates
			Control.isMouseCoordsDisplayed = !Control.isMouseCoordsDisplayed;
			break;
		}
	}
}